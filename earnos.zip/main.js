const fs = require("fs");
const path = require("path");
const axios = require("axios");
const colors = require("colors");
const { HttpsProxyAgent } = require("https-proxy-agent");
const readline = require("readline");
const user_agents = require("./config/userAgents");
const settings = require("./config/config");
const { sleep, loadData, getRandomNumber, saveToken, isTokenExpired, saveJson, updateEnv, decodeJWT } = require("./utils");
const { Worker, isMainThread, parentPort, workerData } = require("worker_threads");
const { checkBaseUrl } = require("./checkAPI");
const headers = require("./core/header");

class ClientAPI {
  constructor(queryId, accountIndex, proxy, baseURL, localStorage) {
    this.headers = headers;
    this.baseURL = baseURL;
    this.queryId = queryId;
    this.accountIndex = accountIndex;
    this.proxy = proxy;
    this.proxyIP = null;
    this.session_name = null;
    this.session_user_agents = this.#load_session_data();
    this.token = queryId;
    this.localStorage = localStorage;
    this.localData = {};
  }

  #load_session_data() {
    try {
      const filePath = path.join(process.cwd(), "session_user_agents.json");
      const data = fs.readFileSync(filePath, "utf8");
      return JSON.parse(data);
    } catch (error) {
      if (error.code === "ENOENT") {
        return {};
      } else {
        throw error;
      }
    }
  }

  #get_random_user_agent() {
    const randomIndex = Math.floor(Math.random() * user_agents.length);
    return user_agents[randomIndex];
  }

  #get_user_agent() {
    if (this.session_user_agents[this.session_name]) {
      return this.session_user_agents[this.session_name];
    }

    console.log(`[Account ${this.accountIndex + 1}] Generating user agent...`.blue);
    const newUserAgent = this.#get_random_user_agent();
    this.session_user_agents[this.session_name] = newUserAgent;
    this.#save_session_data(this.session_user_agents);
    return newUserAgent;
  }

  #save_session_data(session_user_agents) {
    const filePath = path.join(process.cwd(), "session_user_agents.json");
    fs.writeFileSync(filePath, JSON.stringify(session_user_agents, null, 2));
  }

  #get_platform(userAgent) {
    const platformPatterns = [
      { pattern: /iPhone/i, platform: "ios" },
      { pattern: /Android/i, platform: "android" },
      { pattern: /iPad/i, platform: "ios" },
    ];

    for (const { pattern, platform } of platformPatterns) {
      if (pattern.test(userAgent)) {
        return platform;
      }
    }

    return "Unknown";
  }

  #set_headers() {
    const platform = this.#get_platform(this.#get_user_agent());
    this.headers["sec-ch-ua"] = `Not)A;Brand";v="99", "${platform} WebView";v="127", "Chromium";v="127`;
    this.headers["sec-ch-ua-platform"] = platform;
    this.headers["User-Agent"] = this.#get_user_agent();
  }

  createUserAgent() {
    try {
      const info = decodeJWT(this.queryId);
      const { email } = info;
      this.session_name = email;
      this.#get_user_agent();
    } catch (error) {
      this.log(`Can't create user agent, try getting a new query_id: ${error.message}`, "error");
      return;
    }
  }

  async log(msg, type = "info") {
    const timestamp = new Date().toLocaleTimeString();
    const accountPrefix = `[Account ${this.accountIndex + 1}]`;
    const ipPrefix = this.proxyIP ? `[${this.proxyIP}]` : "[Local IP]";
    let logMessage = "";

    switch (type) {
      case "success":
        logMessage = `${accountPrefix}${ipPrefix} ${msg}`.green;
        break;
      case "error":
        logMessage = `${accountPrefix}${ipPrefix} ${msg}`.red;
        break;
      case "warning":
        logMessage = `${accountPrefix}${ipPrefix} ${msg}`.yellow;
        break;
      case "custom":
        logMessage = `${accountPrefix}${ipPrefix} ${msg}`.magenta;
        break;
      default:
        logMessage = `${accountPrefix}${ipPrefix} ${msg}`.blue;
    }
    console.log(logMessage);
  }

  async checkProxyIP() {
    try {
      const proxyAgent = new HttpsProxyAgent(this.proxy);
      const response = await axios.get("https://api.ipify.org?format=json", { httpsAgent: proxyAgent });
      if (response.status === 200) {
        this.proxyIP = response.data.ip;
        return response.data.ip;
      } else {
        throw new Error(`Cannot check proxy IP. Status code: ${response.status}`);
      }
    } catch (error) {
      throw new Error(`Error checking proxy IP: ${error.message}`);
    }
  }

  async runAccount() {
    const info = decodeJWT(this.queryId);
    const { email, username, exp } = info;
    if (Math.floor(Date.now() / 1000) > exp) {
      console.log(`Account ${this.accountIndex + 1} | ${username || email} Token expired`.yellow);
      return null;
    }
    this.session_name = email;
    this.#set_headers();
    this.localData = this.localStorage[email];

    if (settings.USE_PROXY) {
      try {
        this.proxyIP = await this.checkProxyIP();
      } catch (error) {
        this.log(`Cannot check proxy IP: ${error.message}`, "warning");
        return;
      }
      const timesleep = getRandomNumber(settings.DELAY_START_BOT[0], settings.DELAY_START_BOT[1]);
      console.log(`=========Account ${this.accountIndex + 1} | ${username || email} | ${this.proxyIP} | Starting in ${timesleep} seconds...`.green);
      await sleep(timesleep);
    }

    const token = await this.getValidToken();
    if (!token) return this.log(`Can't get token for account ${this.accountIndex + 1}, skipping...`, "error");

    if (true) {
      this.log(`Email: ${this.session_name} | Name: ${username} `, "custom");
      const lastCheckIn = this.localData?.lastCheckIn;
      if (!isCheckedInToday(lastCheckIn) || !lastCheckIn) {
        this.log("Starting check-in...");
        await sleep(1);
        await this.handleCheckIn();
      } else {
        this.log("You have already checked in today.".yellow);
      }
    }
  }
}

async function main() {
  const queryIds = loadData("tokens.txt");
  const proxies = loadData("proxy.txt");
  const localStorage = require("./localStorage.json");

  console.log("Tool developed by the forestarmy Telegram group (https://t.me/forestarmy)".yellow);
  if (!settings.USE_PROXY) {
    console.log(`You are running the bot without proxies!!!`.yellow);
  }

  const { endpoint: hasIDAPI, message } = await checkBaseUrl();
  if (!hasIDAPI) return console.log(`Cannot find ID API, try again later!`.red);
  console.log(`${message}`.yellow);

  queryIds.map((val, i) => new ClientAPI(val, i, proxies[i], hasIDAPI, {}).createUserAgent());

  await sleep(1);
  while (true) {
    let currentIndex = 0;

    while (currentIndex < queryIds.length) {
      const batchSize = Math.min(settings.MAX_THREADS, queryIds.length - currentIndex);
      for (let i = 0; i < batchSize; i++) {
        const worker = new Worker(__filename, {
          workerData: {
            hasIDAPI,
            queryId: queryIds[currentIndex],
            accountIndex: currentIndex,
            proxy: proxies[currentIndex % proxies.length],
            localStorage,
          },
        });

        worker.on("message", (message) => {
          if (message === "taskComplete") {
            worker.terminate();
          }
        });

        worker.on("error", (error) => {
          console.log(`Worker error for account ${currentIndex}: ${error.message}`);
          worker.terminate();
        });

        currentIndex++;
      }
      await sleep(3000);
    }

    console.log("Tool developed by the forestarmy Telegram group (https://t.me/forestarmy)".yellow);
    console.log(`=============Completed all accounts | Waiting ${settings.TIME_SLEEP} minutes=============`.magenta);
    await sleep(settings.TIME_SLEEP * 60);
  }
}

if (isMainThread) {
  main().catch((error) => {
    console.log("Error:", error);
    process.exit(1);
  });
} else {
  runWorker(workerData);
}